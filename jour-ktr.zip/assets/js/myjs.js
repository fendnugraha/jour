$(document).ready(function () {
    $('table.display').DataTable();
});