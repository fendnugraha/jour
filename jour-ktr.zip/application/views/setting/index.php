<div class="setting-icon d-flex justify-content-between flex-wrap gap-3">
    <a href="<?= base_url('setting/general'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-sliders"></i></h1> <span class="setting-icon-text">General</span>
    </a>
    <a href="<?= base_url('setting/usermng'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-users"></i></h1> <span class="setting-icon-text"> Users</span>
    </a>
    <a href="<?= base_url('setting/contact'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-address-book"></i></h1> <span class="setting-icon-text"> Contacts</span>
    </a>
    <a href="<?= base_url('setting/accounts'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-book-open-reader"></i></h1> <span class="setting-icon-text"> Accounts</span>
    </a>
    <a href="<?= base_url('setting/addWarehouse'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-warehouse"></i></h1> <span class="setting-icon-text"> Warehouse</span>
    </a>
    <!-- <a href="<?= base_url('setting/employes'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-users-line"></i></h1> <span class="setting-icon-text"> Employes</span>
    </a> -->
</div>