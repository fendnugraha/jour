<div class="setting-icon d-flex justify-content-between flex-wrap gap-3">
    <a href="<?= base_url('report/cashflow'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-sliders"></i></h1> <span class="setting-icon-text">Cashflow</span>
    </a>
    <a href="<?= base_url('report/neraca'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-scale-balanced"></i></h1> <span class="setting-icon-text">Neraca Lajur</span>
    </a>
    <a href="<?= base_url('report/profitLossStatement'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-sack-dollar"></i></h1> <span class="setting-icon-text">Laba Rugi</span>
    </a>
    <a href="<?= base_url('report/generalLedger'); ?>" class="setting-icon-action">
        <h1><i class="fa-solid fa-book"></i></h1> <span class="setting-icon-text">Buku Besar</span>
    </a>
</div>